
#define u8  unsigned char
#define u16 unsigned short
typedef  unsigned int  size_t;

