//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by hclient.rc
//
#define IDC_EDIT_OUT                    1192
#define IDC_EDIT_IN                     1193
#define IDC_BUTTON_WR                   1194
#define IDC_BUTTON_SET                  1195
#define IDC_BUTTON_RD                   1196
#define IDC_BUTTON_GET                  1197
#define IDC_CHECK_LED1                  1198
#define IDC_CHECK_LED2                  1199
#define IDC_CHECK_BTN1                  1200
#define IDC_CHECK_BTN2                  1201
#define IDC_CHECK_OH                    1202
#define IDC_CHECK_IH                    1203
#define IDC_CHECK_IA                    1203
#define IDC_CHECK_MON                   1204
#define IDC_CHECK_UP                    1205
#define IDC_CHECK_LEFT                  1206
#define IDC_CHECK_DOWN                  1207
#define IDC_CHECK_RIGHT                 1208

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1205
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
